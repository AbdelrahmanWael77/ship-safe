# Implementation Status — Living Checkpoint

> INITIAL TEMPLATE ONLY. At installation, reconcile this with the **existing project**, preserving any more complete status record. Phase 0 is completed per project owner; do not redo it.

- **Roadmap/phase file:** [identify path in existing repository]
- **Current phase:** [first incomplete phase after Phase 0]
- **Active task:** [smallest unfinished task in that phase]
- **Last updated:** [date/time]
- **Branch / latest commit:** [if available]

## Completed and verified
- Phase 0 — completed (as confirmed by project owner)
- [Only actual completed tasks + evidence; do not invent]

## Current working state
- **Functional now:** [what was verified]
- **Changed files:** [paths + 1-line descriptions]
- **Tests/commands:** [exact commands and pass/fail results]
- **In-progress or uncommitted work:** [what is incomplete and must not be lost]

## Blockers / known issues
- [None verified yet / enumerate precise blockers]

## Next exact task
- **Goal:** [one atomic deliverable]
- **Likely files:** [paths]
- **Done when:** [observable acceptance check]
- **Avoid:** [specific repeated work or risky overlap]

## Deferred (existing roadmap only)
- [Link or name later-phase features; do not enlarge scope here]
