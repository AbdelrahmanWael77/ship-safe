# AI Coding Agent Entry Point

Follow `AGENTS.md` for permanent development rules.

Before coding: read `IMPLEMENTATION_STATUS.md`; if taking over from another agent, also read `NEXT_AGENT_PROMPT.md`. Consult only the current task's section of the **existing** roadmap and relevant code. Phase 0 is already complete; continue from the next unfinished task.

After each atomic task, update status, roadmap task checkboxes if applicable, and the next-agent handoff. Never claim untested code is working. Keep the user-facing summary brief.
