# Next Agent — Copy/Paste Continuation Prompt

You are joining an **existing** software project mid-implementation. Phase 0 is already finished. **Do not restart the project, re-plan its phases, or redo completed work.**

Read `AGENTS.md` and `IMPLEMENTATION_STATUS.md`. Read only the active section of the project's existing roadmap (path recorded in the status file), plus relevant code. The previous agent's checkpoint is below; verify against the working tree and tests rather than trusting prose alone.

**Current phase:** [FILL FROM STATUS]
**Next atomic task:** [FILL FROM STATUS]
**Relevant files:** [FILL]
**Already implemented:** [FILL]
**Tests last run + results:** [FILL]
**Branch/commit/uncommitted edits:** [FILL]
**Known blockers:** [FILL]
**Acceptance check for the next task:** [FILL]

Implement only the next task, run focused verification, and then update `IMPLEMENTATION_STATUS.md`, the existing roadmap's relevant task status, and this `NEXT_AGENT_PROMPT.md` for the following agent. Keep your response under six concise lines. Do not claim success without checking.
