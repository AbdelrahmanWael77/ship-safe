# Project Agent Rules — Lean Build & Handoff

These rules apply to every AI coding agent working in this repository. The project and its phase plan already exist. **Phase 0 is complete. Do not restart it.**

## Sources of truth
- Existing project code + successful tests determine what is actually implemented.
- Existing phase/roadmap document determines scope, phase names, and sequencing. **Do not replace it with a generic roadmap.**
- `IMPLEMENTATION_STATUS.md` is the compact checkpoint. If it conflicts with code/tests, correct the status.
- `NEXT_AGENT_PROMPT.md` is the handoff to the next AI agent, not a new specification.

## At the start of each implementation task
1. Read this short file and `IMPLEMENTATION_STATUS.md`.
2. Read only the active phase/task portion of the existing roadmap and the relevant code. The roadmap file path should be recorded in the status file.
3. If joining after another agent, also read `NEXT_AGENT_PROMPT.md` and verify any claimed uncommitted work.
4. Resume the **first unfinished task after completed Phase 0**. Never redo finished work just to standardize it.

## Build rules
- One small, independently testable task at a time; prefer an end-to-end useful slice.
- Reuse existing working code, style, architecture, and dependencies where practical.
- No unsolicited redesign, broad refactor, verbose documents, speculative features, or premature integrations.
- Protect essential security, authorization, data isolation, secrets, and integrity; these are not optional shortcuts.
- Keep the current phase's acceptance criteria and avoid implementing later-phase features unless a genuine dependency requires it.
- Verify with focused tests; distinguish tested functionality from assumptions, mocks, and demo behavior.
- Preserve existing roadmap and status content; edit or merge rather than blindly overwrite.

## After EVERY task (mandatory, not only near quota limits)
1. Update `IMPLEMENTATION_STATUS.md`: active phase, completed task, changed files, commands/tests and results, known issues, exact next task.
2. Update the existing roadmap's task statuses **only where appropriate**; do not replan or rename phases.
3. Rewrite `NEXT_AGENT_PROMPT.md` as a paste-ready handoff using the *actual* state of the repository.
4. If using Git, keep changes coherent and commit when appropriate/authorized. Record branch/commit and uncommitted edits; do not silently discard other agents' changes.
5. Report succinctly: done, verified, blocker, next.

## On interruption, quota exhaustion or model switching
An agent may not know its remaining quota. Make handoffs continuously. If it notices little context/time remains, stop starting new work, preserve unfinished edits, mark incomplete tests honestly, and refresh both handoff files. The next agent must be able to continue from project files alone, without chat history. Avoid concurrent agents editing the same files without coordination.
